pools = [ \
  {
    "name": "btcguild", \
    "servers": [ \
      {"host": "btcguild.com", "port": 8332}, \
    ], \
    "username": "USERNAME", \
    "password": "PASSWORD", \
  }, \
]
